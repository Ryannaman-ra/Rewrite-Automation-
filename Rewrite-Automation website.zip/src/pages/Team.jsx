import React from 'react';
import { motion } from 'framer-motion';
import { Linkedin, Award, GraduationCap, Lightbulb } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';

export default function Team() {
  const team = [
    {
      name: 'Rohith Yannamaneni',
      title: 'Founder & Principal Ignition Integrator',
      location: 'Milford, Michigan, USA',
      photo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69373ef99c7d22429e61ba82/000ab7547_image.png',
      description: 'Leading the technical vision and client delivery for all Ignition projects.',
      responsibilities: [
        'Leads design and delivery of Ignition-based SCADA, MES, and industrial automation solutions',
        'Architects end-to-end systems: PLCs, OPC UA/MQTT, databases, and Ignition Perspective/Vision',
        'Defines integration standards, project templates, and best practices for all Ignition projects',
        'Primary point of contact for Inductive Automation, clients, and project stakeholders'
      ],
      linkedin: 'https://www.linkedin.com/in/rohith-yannamaneni-632782104/'
    },
    {
      name: 'Dr. Giscard Kfoury',
      title: 'Technical Advisor – Robotics & Industrial Automation Systems',
      location: 'Associate Professor, Lawrence Technological University',
      photo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69373ef99c7d22429e61ba82/f039354ac_image.png',
      description: 'Providing technical oversight on robotics, motion systems, and plant-floor integration.',
      responsibilities: [
        'Provides technical oversight on robotics, motion systems, and plant-floor integration for Ignition projects',
        'Reviews control architectures (PLC, drives, sensors) to ensure safety, reliability, and standards compliance',
        'Guides mechatronics-focused client projects (robot cells, test rigs, R&D labs) using Ignition as the supervisory layer',
        'Expertise in vehicle labs, motorsports, and hands-on mechatronic systems'
      ],
      linkedin: 'https://ltu.edu/faculty/kfoury-giscard/'
    },
    {
      name: 'Dr. George Pappas',
      title: 'Chief AI & Smart Manufacturing Advisor',
      location: 'Director of MS in AI, Lawrence Technological University',
      photo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69373ef99c7d22429e61ba82/640441e66_image.png',
      description: 'Guiding AI/ML strategy for Ignition-based analytics and intelligent automation.',
      responsibilities: [
        'Advises on AI/ML strategy for Ignition-based analytics, defect detection, and prescriptive maintenance solutions',
        'Reviews architectures that combine Ignition, IIoT data pipelines, and cloud/on-prem analytics tools',
        'Supports development of intelligent modules and training content that blend AI with industrial automation',
        'Specializes in embedded vision, defect detection, and AV safety systems'
      ],
      linkedin: 'https://www.linkedin.com/in/george-p-pappas-ph-d-b0417a1ab/'
    },
    {
      name: 'Suneel Bondada',
      title: 'Senior Ignition Solutions Engineer (SCADA & MES)',
      location: 'Hyderabad, Telangana, India',
      photo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69373ef99c7d22429e61ba82/6802d2e62_image.png',
      description: 'Expert in Ignition implementation, configuration, and system integration.',
      responsibilities: [
        'Designs and configures Ignition projects (tags, UDTs, templates, Perspective views, alarming, reporting)',
        'Integrates PLCs, OPC UA devices, databases, and MQTT brokers into unified Ignition architectures',
        'Leads commissioning, troubleshooting, and performance tuning at customer sites',
        'Microsoft Certified DevOps Engineer | Azure Specialist | Lean Six Sigma Green Belt'
      ],
      linkedin: 'https://www.linkedin.com/in/naga-veera-venu-sai-suneel-bondada/'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-12 sm:py-16 md:py-24 overflow-hidden bg-gradient-to-br from-gray-50 to-white">
        
        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 sm:mb-6 px-4">
              Meet Our <span className="text-[#1599b4]">Team</span>
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-gray-600 leading-relaxed px-4">
              Industry experts and academic leaders combining real-world Ignition expertise with 
              cutting-edge research in automation, AI, and robotics.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Team Members */}
      <section className="py-8 sm:py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8 sm:space-y-12 md:space-y-16">
            {team.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`grid lg:grid-cols-3 gap-8 items-start ${
                  index % 2 === 1 ? 'lg:grid-flow-dense' : ''
                }`}
              >
                {/* Profile Card */}
                <div className={`lg:col-span-1 ${index % 2 === 1 ? 'lg:col-start-3' : ''}`}>
                  <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-lg sticky top-24">
                    {/* Avatar */}
                    <div className="w-32 h-32 rounded-full mx-auto mb-6 overflow-hidden border-4 border-[#1599b4]">
                      <img 
                        src={member.photo} 
                        alt={member.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    <div className="text-center mb-6">
                      <h2 className="text-2xl font-bold text-gray-900 mb-2">{member.name}</h2>
                      <p className="text-[#1599b4] font-semibold mb-2">{member.title}</p>
                      <p className="text-sm text-gray-500">{member.location}</p>
                    </div>

                    {/* LinkedIn Button */}
                    <a
                      href={member.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 w-full bg-[#0077b5] hover:bg-[#006399] text-white rounded-full py-3 px-6 transition-colors"
                    >
                      <Linkedin className="w-5 h-5" />
                      <span className="font-medium">View LinkedIn</span>
                    </a>
                  </div>
                </div>

                {/* Details */}
                <div className={`lg:col-span-2 ${index % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}`}>
                  <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100">
                    <div className="flex items-start gap-3 mb-6">
                      <div className="w-10 h-10 rounded-lg bg-[#1599b4] flex items-center justify-center flex-shrink-0">
                        <Lightbulb className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2">About</h3>
                        <p className="text-gray-600 leading-relaxed">{member.description}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#1599b4] flex items-center justify-center flex-shrink-0">
                        <Award className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-gray-900 mb-4">Key Responsibilities</h3>
                        <ul className="space-y-3">
                          {member.responsibilities.map((resp, idx) => (
                            <li key={idx} className="flex items-start gap-3 text-gray-600">
                              <div className="w-2 h-2 rounded-full bg-[#1599b4] mt-2 flex-shrink-0" />
                              <span className="leading-relaxed">{resp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 sm:py-16 md:py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <GraduationCap className="w-16 h-16 text-[#1599b4] mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Work With Industry Leaders
            </h2>
            <p className="text-xl text-gray-600 mb-10">
              Our team brings together hands-on Ignition expertise, academic research, and real-world 
              manufacturing experience to deliver exceptional results.
            </p>
            <Link to={createPageUrl('Contact')}>
              <button className="bg-[#1599b4] hover:bg-[#127a94] text-white px-8 py-4 rounded-full text-lg font-medium shadow-lg shadow-[#1599b4]/20 transition-all">
                Start Your Project
              </button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}