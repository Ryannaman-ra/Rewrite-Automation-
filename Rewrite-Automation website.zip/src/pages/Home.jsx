import React from 'react';
import HeroSection from '@/components/home/HeroSection';
import ChallengeSection from '@/components/home/ChallengeSection';
import SolutionSection from '@/components/home/SolutionSection';
import IgnitionShowcase from '@/components/home/IgnitionShowcase';
import CompetitiveAdvantage from '@/components/home/CompetitiveAdvantage';

export default function Home() {
  return (
    <div>
      <HeroSection />
      <ChallengeSection />
      <SolutionSection />
      <IgnitionShowcase />
      <CompetitiveAdvantage />
    </div>
  );
}