import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Cpu, 
  Bell, 
  BarChart3, 
  Shield, 
  Zap,
  ArrowRight,
  CheckCircle,
  Clock,
  Mail,
  AlertCircle,
  TrendingUp,
  Activity
} from 'lucide-react';

export default function IgnitionModule() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
    }
  };

  const features = [
    {
      icon: Activity,
      title: 'Real-time Anomaly Detection',
      description: 'AI algorithms continuously monitor your tags and detect unusual patterns in real-time'
    },
    {
      icon: TrendingUp,
      title: 'Predictive Maintenance',
      description: 'Forecast equipment issues before they cause downtime with ML-powered predictions'
    },
    {
      icon: Bell,
      title: 'Smart Alerting',
      description: 'Context-aware notifications that reduce alert fatigue and prioritize critical issues'
    },
    {
      icon: BarChart3,
      title: 'No-Code Configuration',
      description: 'Set up AI models using intuitive configuration panels—no data science degree required'
    },
    {
      icon: Zap,
      title: 'Native SDK Integration',
      description: 'Built as an Ignition module for seamless integration with your existing gateway'
    },
    {
      icon: Shield,
      title: 'On-Premise Processing',
      description: 'All AI processing happens locally—your data never leaves your network'
    }
  ];

  const useCases = [
    {
      title: 'Manufacturing',
      description: 'Detect quality issues, process anomalies, and equipment degradation before they impact production'
    },
    {
      title: 'Water/Wastewater',
      description: 'Monitor pump performance, chemical levels, and flow patterns for early problem detection'
    },
    {
      title: 'Food & Beverage',
      description: 'Track temperature, pressure, and other critical parameters to maintain quality standards'
    },
    {
      title: 'Energy & Utilities',
      description: 'Identify inefficiencies and potential failures in power generation and distribution systems'
    }
  ];

  const timeline = [
    { 
      phase: 'Phase 1', 
      period: 'Q1 2026', 
      milestone: 'Private Beta Launch',
      description: 'Limited beta testing with select partners'
    },
    { 
      phase: 'Phase 2', 
      period: 'Q2 2026', 
      milestone: 'Public Beta Release',
      description: 'Open beta program with expanded features'
    },
    { 
      phase: 'Phase 3', 
      period: 'Q3 2026', 
      milestone: 'General Availability',
      description: 'Full commercial release with support'
    },
  ];

  return (
    <div className="min-h-screen overflow-hidden">
      {/* Hero Section */}
      <section className="relative py-12 sm:py-16 md:py-24 lg:py-32">
        {/* Background Elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/2 w-[800px] h-[800px] rounded-full bg-gradient-to-br from-[#1599b4]/5 to-transparent -translate-x-1/2 -translate-y-1/2" />
        </div>

        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-4xl mx-auto"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
              className="inline-flex items-center gap-2 bg-[#1599b4]/10 text-[#1599b4] px-4 py-2 rounded-full text-sm font-medium mb-8"
            >
              <Clock className="w-4 h-4" />
              Coming Soon
            </motion.div>

            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold text-gray-900 mb-4 sm:mb-6 px-4">
              AI-Powered <span className="text-[#1599b4]">Ignition Module</span>
            </h1>

            <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-gray-600 leading-relaxed mb-8 sm:mb-10 max-w-2xl mx-auto px-4">
              Native anomaly detection and predictive maintenance built directly into Ignition SCADA
            </p>

            {/* Waitlist Form */}
            {!subscribed ? (
              <motion.form
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                onSubmit={handleSubscribe}
                className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto"
              >
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                  className="flex-1 rounded-full border-gray-200 px-6 py-6 text-base focus:border-[#1599b4] focus:ring-[#1599b4]/20"
                />
                <Button 
                  type="submit"
                  size="lg"
                  className="bg-[#1599b4] hover:bg-[#127a94] text-white px-8 py-6 rounded-full shadow-lg shadow-[#1599b4]/20"
                >
                  Join Waitlist
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </motion.form>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="inline-flex items-center gap-3 bg-green-50 text-green-700 px-6 py-4 rounded-full"
              >
                <CheckCircle className="w-5 h-5" />
                <span className="font-medium">You're on the list! We'll notify you when we launch.</span>
              </motion.div>
            )}

            <p className="mt-6 text-sm text-gray-500">
              Be among the first to bring AI to your Ignition system. No spam, ever.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Problem & Solution Section */}
      <section className="py-12 sm:py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              The Challenge We're Solving
            </h2>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Challenge Card */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-gradient-to-br from-red-50 to-orange-50 rounded-3xl p-8 lg:p-10 border-2 border-red-100"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 rounded-2xl bg-red-500 flex items-center justify-center flex-shrink-0">
                  <AlertCircle className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">The Challenge</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Even with powerful Ignition SCADA systems, operators face constant challenges detecting subtle 
                anomalies before they become critical failures.
              </p>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-white text-xs font-bold">1</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 mb-1">Alarm Fatigue</p>
                    <p className="text-gray-600 text-sm">Traditional alarms create noise, missing subtle degradation patterns</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-white text-xs font-bold">2</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 mb-1">Data Overload</p>
                    <p className="text-gray-600 text-sm">Thousands of tags make manual monitoring impossible</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-white text-xs font-bold">3</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 mb-1">Reactive Maintenance</p>
                    <p className="text-gray-600 text-sm">Equipment failures happen suddenly without advance warning</p>
                  </div>
                </li>
              </ul>
            </motion.div>

            {/* Solution Card */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-3xl p-8 lg:p-10 border-2 border-green-200"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 rounded-2xl bg-green-600 flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Our Solution</h3>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Native AI module that seamlessly integrates with your existing Ignition gateway—no cloud, 
                no external dependencies, complete control.
              </p>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-green-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 mb-1">Intelligent Pattern Learning</p>
                    <p className="text-gray-600 text-sm">AI automatically learns normal operating patterns and detects deviations</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-green-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 mb-1">Predictive Alerts</p>
                    <p className="text-gray-600 text-sm">Forecast issues hours or days in advance with actionable insights</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-green-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 mb-1">No-Code Configuration</p>
                    <p className="text-gray-600 text-sm">Configure through Ignition Designer—no data science expertise required</p>
                  </div>
                </li>
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Preview */}
      <section className="py-12 sm:py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Module Features
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Powerful AI capabilities designed specifically for industrial operations
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 border border-gray-100 hover:shadow-lg hover:border-[#1599b4]/20 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-[#1599b4]/10 flex items-center justify-center mb-5">
                  <feature.icon className="w-6 h-6 text-[#1599b4]" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="py-12 sm:py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Industry Applications
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Versatile AI detection for any industrial operation
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {useCases.map((useCase, index) => (
              <motion.div
                key={useCase.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 border border-gray-100"
              >
                <h3 className="text-xl font-bold text-gray-900 mb-3">{useCase.title}</h3>
                <p className="text-gray-600">{useCase.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-12 sm:py-16 md:py-24">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Development Roadmap
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {timeline.map((item, index) => (
              <motion.div
                key={item.phase}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
                className={`relative rounded-2xl p-8 ${
                  index === 0 
                    ? 'bg-[#a3e635] text-gray-900' 
                    : index === 1 
                    ? 'bg-[#1599b4] text-white' 
                    : 'bg-[#22c55e] text-white'
                }`}
              >
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-6 ${
                  index === 0 ? 'bg-white/30' : 'bg-white/20'
                }`}>
                  <span className="text-lg font-bold">0{index + 1}</span>
                </div>
                <p className={`text-sm font-semibold mb-2 ${
                  index === 0 ? 'text-gray-700' : 'text-white/80'
                }`}>
                  {item.phase}
                </p>
                <h3 className="text-xl font-bold mb-2">{item.period}</h3>
                <p className={`font-semibold mb-2 ${index === 0 ? 'text-gray-800' : 'text-white'}`}>
                  {item.milestone}
                </p>
                <p className={`text-sm ${index === 0 ? 'text-gray-600' : 'text-white/80'}`}>
                  {item.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 sm:py-16 md:py-24 bg-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full bg-[#1599b4]/30 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-[#22c55e]/30 blur-3xl" />
        </div>

        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Mail className="w-16 h-16 text-[#1599b4] mx-auto mb-8" />
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Join the Beta Program
            </h2>
            <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
              Be among the first to test AI-powered anomaly detection in your Ignition system
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              {!subscribed ? (
                <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-4 w-full max-w-md">
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    required
                    className="flex-1 rounded-full bg-white/10 border-white/20 text-white placeholder:text-gray-400 px-6 py-6"
                  />
                  <Button 
                    type="submit"
                    size="lg"
                    className="bg-[#1599b4] hover:bg-[#127a94] text-white px-8 py-6 rounded-full"
                  >
                    Get Early Access
                  </Button>
                </form>
              ) : (
                <div className="inline-flex items-center gap-3 bg-green-500/20 text-green-400 px-6 py-4 rounded-full">
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-medium">You're all set!</span>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}