import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { 
  Monitor, 
  Network, 
  Layers, 
  Database, 
  RefreshCw, 
  GraduationCap,
  ArrowRight,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: Monitor,
      title: 'Ignition Development & Implementation',
      description: 'Complete Ignition platform implementation from design to deployment, tailored to your operational needs.',
      features: [
        'Gateway architecture design',
        'Tag structure & organization',
        'Alarm configuration',
        'User management & security'
      ]
    },
    {
      icon: Network,
      title: 'SCADA System Integration',
      description: 'Seamless integration of field devices, PLCs, and enterprise systems into a unified Ignition platform.',
      features: [
        'Multi-vendor PLC connectivity',
        'OPC UA/DA integration',
        'Protocol conversion',
        'Real-time data aggregation'
      ]
    },
    {
      icon: Layers,
      title: 'HMI & Visualization Design',
      description: 'Intuitive and responsive HMI interfaces that provide operators with clear, actionable insights.',
      features: [
        'Perspective module development',
        'Vision module screens',
        'Mobile-responsive design',
        'Custom components & templates'
      ]
    },
    {
      icon: Database,
      title: 'Database Integration & Reporting',
      description: 'Powerful data management and reporting solutions leveraging Ignition\'s database capabilities.',
      features: [
        'Historian configuration',
        'SQL Bridge integration',
        'Custom report generation',
        'Data analysis dashboards'
      ]
    },
    {
      icon: RefreshCw,
      title: 'System Upgrades & Migration',
      description: 'Modernize legacy SCADA systems with seamless migration to Ignition platform.',
      features: [
        'Legacy system assessment',
        'Zero-downtime migration',
        'Version upgrades',
        'Performance optimization'
      ]
    },
    {
      icon: GraduationCap,
      title: 'Training & Support',
      description: 'Comprehensive training programs and ongoing support to empower your team.',
      features: [
        'Administrator training',
        'Developer workshops',
        'End-user training',
        '24/7 support packages'
      ]
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden bg-gradient-to-br from-gray-50 to-white">
        
        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
              Ignition <span className="text-[#1599b4]">Services</span>
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              Comprehensive Ignition integration services from system design to ongoing support
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 border border-gray-100 hover:shadow-xl hover:border-[#1599b4]/20 transition-all duration-300 group"
              >
                <div className="w-14 h-14 rounded-xl bg-[#1599b4]/10 flex items-center justify-center mb-6 group-hover:bg-[#1599b4] transition-colors duration-300">
                  <service.icon className="w-7 h-7 text-[#1599b4] group-hover:text-white transition-colors duration-300" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                
                <ul className="space-y-3">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3 text-sm text-gray-600">
                      <CheckCircle2 className="w-4 h-4 text-[#1599b4] flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Innovation Section */}
      <section className="py-24 relative overflow-hidden">
        
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-gradient-to-br from-[#1599b4] to-[#127a94] rounded-3xl p-12 text-white"
          >
            <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-6">
              <Sparkles className="w-8 h-8" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Next-Gen AI Module Coming Soon
            </h2>
            <p className="text-xl text-white/90 mb-8 leading-relaxed">
              We're developing an innovative AI-powered anomaly detection module for Ignition. 
              Be the first to know when it launches.
            </p>
            <div className="flex justify-center">
              <Link to={createPageUrl('IgnitionModule')}>
                <Button 
                  size="lg"
                  variant="outline"
                  className="bg-white text-[#1599b4] hover:bg-gray-50 border-0 px-8 py-6 text-base rounded-full"
                >
                  Learn About the Module
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Ready to Modernize Your Operations?
            </h2>
            <p className="text-xl text-gray-600 mb-10">
              Let's discuss how Ignition can transform your industrial automation infrastructure.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to={createPageUrl('Contact')}>
                <Button 
                  size="lg"
                  className="bg-[#1599b4] hover:bg-[#127a94] text-white px-8 py-6 text-base rounded-full shadow-lg shadow-[#1599b4]/20"
                >
                  Start Your Project
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}