import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { motion } from 'framer-motion';
import { Users, Target, Award, Zap, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function AboutUs() {
  const stats = [
    { value: '15+', label: 'Ignition Projects' },
    { value: '10+', label: 'Industrial Clients' },
    { value: 'Certified', label: 'Ignition Integrator' },
    { value: '5+ Years', label: 'Industry Experience' },
  ];

  const team = [
    {
      name: 'Rohith Yannamaneni',
      role: 'Founder & Principal Ignition Integrator',
      photo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69373ef99c7d22429e61ba82/000ab7547_image.png'
    },
    {
      name: 'Dr. Giscard Kfoury',
      role: 'Technical Advisor – Robotics & Systems',
      photo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69373ef99c7d22429e61ba82/f039354ac_image.png'
    },
    {
      name: 'Dr. George Pappas',
      role: 'Chief AI & Smart Manufacturing Advisor',
      photo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69373ef99c7d22429e61ba82/640441e66_image.png'
    },
    {
      name: 'Suneel Bondada',
      role: 'Senior Ignition Solutions Engineer',
      photo: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69373ef99c7d22429e61ba82/6802d2e62_image.png'
    }
  ];

  const values = [
    {
      icon: Target,
      title: 'Excellence',
      description: 'Delivering best-in-class Ignition implementations with meticulous attention to detail and quality.'
    },
    {
      icon: Zap,
      title: 'Innovation',
      description: 'Staying at the forefront of industrial automation technology and Ignition platform capabilities.'
    },
    {
      icon: Users,
      title: 'Partnership',
      description: 'Building long-term relationships with clients through exceptional service and support.'
    },
    {
      icon: Award,
      title: 'Expertise',
      description: 'Deep knowledge of Ignition platform, industrial protocols, and manufacturing operations.'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-12 sm:py-16 md:py-24 overflow-hidden bg-gradient-to-br from-gray-50 to-white">
        
        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69373ef99c7d22429e61ba82/6c802f05d_image.png" 
              alt="Registered Ignition Integrator" 
              className="h-20 w-auto mx-auto mb-6"
            />
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 sm:mb-6 px-4">
              About <span className="text-[#1599b4]" style={{ textDecoration: 'line-through' }}>Rewrite</span> <span className="text-gray-900">Automation</span>
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-gray-600 leading-relaxed px-4">
              Your trusted partner for Ignition SCADA implementation and industrial automation solutions. 
              Building the future with innovative technology.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-8 sm:py-12 md:py-16 bg-[#1599b4]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 md:gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-1 sm:mb-2">{stat.value}</div>
                <div className="text-white/80 text-xs sm:text-sm md:text-base">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-12 sm:py-16 md:py-24">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="prose prose-lg max-w-none"
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
            <p className="text-gray-600 leading-relaxed mb-6">
              Rewrite Automation was founded with a clear mission: to help manufacturers unlock the full potential 
              of the Ignition platform. With deep expertise in industrial automation and hands-on experience at 
              leading manufacturing facilities, we understand the unique challenges facing today's operations.
            </p>
            <p className="text-gray-600 leading-relaxed">
              We specialize in delivering complete Ignition solutions—from initial design and implementation to 
              training and ongoing support. Our approach combines technical excellence with a commitment to 
              understanding your specific operational needs, ensuring solutions that deliver real value.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-12 sm:py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Our Values</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 md:gap-8">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center p-6 rounded-2xl bg-white hover:shadow-lg border border-transparent hover:border-gray-100 transition-all duration-300"
              >
                <div className="w-14 h-14 rounded-xl bg-[#1599b4]/10 flex items-center justify-center mx-auto mb-5">
                  <value.icon className="w-7 h-7 text-[#1599b4]" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Preview Section */}
      <section className="py-12 sm:py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Our Leadership Team</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Industry experts and academic leaders driving innovation in industrial automation
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8 sm:mb-12">
            {team.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-xl hover:border-[#1599b4]/20 transition-all duration-300 text-center"
              >
                <div className="w-20 h-20 rounded-full mx-auto mb-4 overflow-hidden border-2 border-[#1599b4]">
                  <img 
                    src={member.photo} 
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-1">{member.name}</h3>
                <p className="text-sm text-gray-600">{member.role}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <Link to={createPageUrl('Team')}>
              <Button 
                size="lg"
                className="bg-[#1599b4] hover:bg-[#127a94] text-white px-8 py-6 text-base rounded-full shadow-lg shadow-[#1599b4]/20"
              >
                Meet the Full Team
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Innovation Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-white rounded-2xl p-10 text-center border border-gray-100"
          >
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              Looking Ahead
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              While we excel at traditional Ignition integration, we're also pushing boundaries. 
              We're currently developing an AI-powered anomaly detection module that will bring 
              machine learning capabilities natively to the Ignition platform.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}