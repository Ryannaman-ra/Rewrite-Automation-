import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function HeroSection() {
  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 w-[1000px] h-[1000px] rounded-full bg-gradient-to-br from-[#1599b4]/5 to-transparent -translate-x-1/2 -translate-y-1/2" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center justify-center gap-2 mb-8">
              <span className="text-[#1599b4] font-semibold text-4xl md:text-5xl lg:text-6xl tracking-tight" style={{ textDecoration: 'line-through', fontWeight: 500 }}>Rewrite</span>
              <span className="text-gray-900 font-semibold text-4xl md:text-5xl lg:text-6xl tracking-tight" style={{ fontWeight: 600 }}> Automation</span>
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-5xl md:text-6xl lg:text-8xl text-[#1599b4] tracking-tight mb-8"
            style={{ fontWeight: 700, letterSpacing: '-0.02em' }}
          >
            Ignition Experts
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-10"
          >
            <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed mb-6">
              Delivering SCADA, HMI, and Industrial Automation Solutions powered by Ignition
            </p>
            <div className="flex justify-center">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69373ef99c7d22429e61ba82/6c802f05d_image.png" 
                alt="Registered Ignition Integrator" 
                className="h-24 w-auto"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link to={createPageUrl('Services')}>
              <Button 
                size="lg"
                className="bg-[#1599b4] hover:bg-[#127a94] text-white px-8 py-6 text-base rounded-full transition-all duration-300 shadow-lg shadow-[#1599b4]/20 hover:shadow-xl hover:shadow-[#1599b4]/30"
              >
                Explore Now
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link to={createPageUrl('IgnitionModule')}>
              <Button 
                variant="outline"
                size="lg"
                className="border-2 border-gray-200 text-gray-700 hover:border-[#1599b4] hover:text-[#1599b4] px-8 py-6 text-base rounded-full transition-all duration-300"
              >
                View Ignition Module
              </Button>
            </Link>
          </motion.div>
        </div>
      </div>


    </section>
  );
}