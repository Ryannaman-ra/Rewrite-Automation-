import React from 'react';
import { motion } from 'framer-motion';

export default function SolutionSection() {
  const solutions = [
    { title: 'Full-Stack Ignition Development', position: 'left' },
    { title: 'PLC & Device Integration', position: 'right' },
    { title: 'Custom HMI & Visualization', position: 'left' },
    { title: 'Database Architecture & Reporting', position: 'right' },
    { title: 'System Migration & Upgrades', position: 'left' },
    { title: 'Training & Long-term Support', position: 'right' },
  ];

  return (
    <section className="py-24 bg-gray-50 relative overflow-hidden">

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-3xl md:text-5xl font-bold text-center text-gray-900 mb-16"
        >
          Solution
        </motion.h2>

        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {solutions.map((solution, index) => (
            <motion.div
              key={solution.title}
              initial={{ opacity: 0, x: solution.position === 'left' ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`flex items-center gap-4 bg-white rounded-2xl px-6 py-5 shadow-sm border border-gray-100 hover:shadow-lg hover:border-[#1599b4]/30 transition-all duration-300 ${
                solution.position === 'left' ? 'md:flex-row' : 'md:flex-row-reverse'
              }`}
            >
              <div className="w-10 h-10 rounded-full bg-[#1599b4]/10 flex items-center justify-center flex-shrink-0">
                <div className="w-3 h-3 rounded-full bg-[#1599b4]" />
              </div>
              <h3 className="text-base font-semibold text-gray-800">{solution.title}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}