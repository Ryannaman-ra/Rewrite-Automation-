import React from 'react';
import { motion } from 'framer-motion';
import { FileCheck, AlertTriangle, Settings, Cpu } from 'lucide-react';

export default function ChallengeSection() {
  const challenges = [
    {
      icon: AlertTriangle,
      title: 'Complex System Integration',
    },
    {
      icon: Settings,
      title: 'Legacy System Modernization',
    },
    {
      icon: Cpu,
      title: 'Real-time Data Visibility',
    },
  ];

  return (
    <section id="challenge-section" className="py-24 relative overflow-hidden">

      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Side */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative w-80 h-80 lg:w-96 lg:h-96 mx-auto">
              <div className="absolute inset-0 rounded-full border-2 border-gray-100" />
              <div className="absolute inset-4 rounded-full bg-gray-50 flex items-center justify-center">
                <div className="text-center px-8">
                  <div className="w-16 h-16 mx-auto mb-6 text-[#1599b4]">
                    <FileCheck className="w-full h-full" strokeWidth={1.5} />
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                    Industry<br />Challenge
                  </h2>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Side - Challenges */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            {challenges.map((challenge, index) => (
              <motion.div
                key={challenge.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="flex items-center gap-4 bg-white rounded-2xl px-6 py-5 shadow-sm border border-gray-100 hover:shadow-md hover:border-[#1599b4]/20 transition-all duration-300"
                >
                <div className="w-10 h-10 rounded-full bg-[#1599b4]/10 flex items-center justify-center flex-shrink-0">
                  <div className="w-3 h-3 rounded-full bg-[#1599b4]" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">{challenge.title}</h3>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Bottom Text */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-16 text-center max-w-4xl mx-auto"
        >
          <p className="text-xl md:text-2xl text-gray-600 leading-relaxed">
            Industrial facilities struggle with fragmented systems, outdated infrastructure, and limited operational visibility.
            <span className="block mt-2">
              The right Ignition implementation transforms operations with unified data and powerful automation
            </span>
          </p>
        </motion.div>
      </div>
    </section>
  );
}