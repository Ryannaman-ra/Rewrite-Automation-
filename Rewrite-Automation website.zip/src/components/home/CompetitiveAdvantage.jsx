import React from 'react';
import { motion } from 'framer-motion';

export default function CompetitiveAdvantage() {
  const competitors = [
    { name: 'Innorobix', score: 67, color: '#4338ca' },
    { name: 'DeepIQ', score: 68, color: '#6366f1' },
    { name: 'Seeq Corp', score: 63, color: '#3b82f6' },
    { name: 'Radix IOT', score: 60, color: '#22d3ee' },
    { name: 'IBM Maximo', score: 45, color: '#a16207' },
    { name: 'Predixion', score: 47, color: '#f59e0b' },
  ];

  const advantages = [
    { score: '20/20', label: 'Ignition Integration' },
    { score: '20/20', label: 'AI Capability' },
    { score: '20/20', label: 'SaaS Model Fit' },
    { score: '20/20', label: 'SME Market Fit' },
    { score: '20/20', label: 'Competitive Advantage' },
  ];

  const CircularProgress = ({ score, color, size = 120 }) => {
    const strokeWidth = 8;
    const radius = (size - strokeWidth) / 2;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - (score / 100) * circumference;

    return (
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="transform -rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#f1f5f9"
            strokeWidth={strokeWidth}
          />
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            whileInView={{ strokeDashoffset }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, ease: 'easeOut' }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-2xl font-bold text-gray-900">{score}%</span>
        </div>
      </div>
    );
  };

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Competitors Grid */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8"
          >
            {competitors.map((competitor, index) => (
              <motion.div
                key={competitor.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="flex flex-col items-center"
              >
                <CircularProgress score={competitor.score} color={competitor.color} />
                <p className="mt-4 text-sm font-semibold text-[#1599b4] text-center">{competitor.name}</p>
              </motion.div>
            ))}
          </motion.div>

          {/* Vertech Score */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <div className="flex items-center justify-center gap-2 mb-8">
              <span className="text-[#1599b4] font-bold text-3xl" style={{ textDecoration: 'line-through' }}>Rewrite</span>
              <span className="text-gray-900 font-bold text-3xl"> Automation</span>
            </div>

            {/* Main Score */}
            <div className="flex justify-center mb-10">
              <div className="relative w-48 h-48">
                <svg width="192" height="192" className="transform -rotate-90">
                  <circle cx="96" cy="96" r="84" fill="none" stroke="#f1f5f9" strokeWidth="12" />
                  <motion.circle
                    cx="96"
                    cy="96"
                    r="84"
                    fill="none"
                    stroke="#22c55e"
                    strokeWidth="12"
                    strokeLinecap="round"
                    strokeDasharray={2 * Math.PI * 84}
                    initial={{ strokeDashoffset: 2 * Math.PI * 84 }}
                    whileInView={{ strokeDashoffset: 2 * Math.PI * 84 * (1 - 0.91) }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.5, ease: 'easeOut' }}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-5xl font-bold text-gray-900">91%</span>
                </div>
              </div>
            </div>

            {/* Advantages Grid */}
            <div className="grid grid-cols-2 gap-4">
              {advantages.map((advantage, index) => (
                <motion.div
                  key={advantage.label}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-3"
                >
                  <span className="text-[#1599b4] font-bold text-sm">{advantage.score}</span>
                  <span className="text-gray-600 text-sm">{advantage.label}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}